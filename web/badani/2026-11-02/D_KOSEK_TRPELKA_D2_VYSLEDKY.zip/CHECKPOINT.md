# CHECKPOINT — D_KOSEK_TRPELKA (aktualizováno 2026-11-02 ~18:30 CET)

## Hotovo
- [x] Resume ověření prostředí → `D_checkpoint_resume.md` + `.json` (ZIP SHA256 sedí, vstupy identické)
- [x] **D1 čtení**: zápis č. 53, pag. 94, Anno 1919, tomus V. — ženich „Cyrill Kosek“ (zřetelné), syn Josefa Koseka chalupníka (Tvrdonice) a Františky roz. Š…[?]; nevěsta „Alžběta Trpětka[?]/Trpětková[?]“, dělnice z Kostic, dcera Josefa Trpětky chalupníka (Kostice) a Julany roz. (Josefa) Prokopa[?]; věky „2[8|9] 1/2[?]“ × „2[2|3] 1/2[?]“; rotované „Nar. …“ zůstávají [?] (limit 2 cílených výřezů vyčerpán)
- [x] **D1 katalog** (vlastní ověření): 3443=detail/258 (oddaní 1909–1925, Kostice, 95 sn.) ✓; 3454=detail/12042 (rejstříky: zemřelí sn.2–63, oddaní sn.64–103, narození sn.104–172) ✓ → sn. 49 knihy 3454 = index zemřelých
- [x] D1 výstupy: PREPIS MD+JSON, PRAMENY.csv v1, DENÍK, obrazy A1–A4/C1/C2+kopie vstupu, ZIP D1

## Překážky (bez obcházení)
- raster/IIIF MZA za ALTCHA → pixelová identifikace snímku + čtení rejstříku K/T 1919 (3454 sn. 64–103) nedostupné
- katalog hledání = POST/JS (curl 2× timeout); `matrika/obec/15` 404 → seznam knih obce nemám

## Probíhá
- [ ] D2: hledání oficiálního seznamu knih farnosti Tvrdonice (stránka „podle původce“) → narozená ~1888–1898 (pár) a oddací ~1880–1908 (rodiče)

## Nejisté (ponechány [?])
- příjmení nevěsty (Trpětka vs Trpělková), matky ženicha („Štrukáni…“), věkové zlomky, rotované „Nar. …“, svědek 2 a „oba Kab…“

## Další krok
1. WebFetch `matrika/puvodce` → najít ID původce „Tvrdonice ř.k.“ → seznam všech knih farnosti → určit narozenou knihu s roky ~1884–1912 a oddací knihy do 1909.
