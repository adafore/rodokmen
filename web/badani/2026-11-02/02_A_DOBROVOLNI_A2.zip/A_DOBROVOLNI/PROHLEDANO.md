# PROHLEDANO — negativní a pozitivní rozsahy (balík A)

## Kniha 2755 (oddaní Klobouky u Brna 1883–1948, 166 snímků) — hledání sňatku rodičů
| snímky | prohlédnuto | výsledek |
|---|---|---|
| 32 | celá dvojstrana L12 (y1500–5465) | zápisy ~srpen/září 1899 — Dobrovolný×Tihlař(íková) NE |
| 33 | celá dvojstrana L12 | zápisy ~srpen 1899 (června–srpna) — NE |
| 34 | celá dvojstrana L12 + horní zápis L13 | **HIT: sňatek 4.10.1899** (horní zápis levé strany); pravá strana = „Léta Páně 1900" |
| 37, 38, 39 | horní pás L12 (y1600–2200) | 37: ~1900/01; 39: konec 1901 (certifikace „Klobouky 31 prosince 1901") + leden 1902 — NE |
| 40, 41 | horní pás L12 | 40: ~1901; 41: ručně „1902" — NE |
| 36 | vizuálně v prohlížeči (snímek celý) | ~1900 — NE |

Pozn.: ročníky 1883–1898 (snímky 2–31) a 1903–1948 pro hledání tohoto sňatku prohlédnuty
NEBYLY — nenutné: zápis byl nalezen na snímku 34 a identifikován obsahově (dvojitá
shoda rodičů z rod. zápisu Anny). Negativní rozsah se týká jen vyloučení duplicitního
zápisu v okolních snímcích 32–41.

## Katalog ActaPublica
- hledání podle signatury 2736 → ID 14893 ✓ (narození 1883–1925)
- obec_id=618 → kompletní seznam knih farnosti (11× narození, 6× oddaní, 3× zemřelí; žádné rejstříky)
- ID 2786 → Křepice, narození 1841–1875 (stará stopa „rejstřík 2786" tímto vyvrácena)

## Kniha 2745 (narození 1859–1882) — pro A3
(vyplní se v úkolu A3)
