# CHECKPOINT — balík A (Anna Dobrovolná a její rodiče)

**Stav:** 2. 11. 2026, 14:15 UTC (~63 min práce)

## Dokončeno
- [x] Vstupní ZIP ověřen (5/5 SHA256)
- [x] **A1 HOTOV** — rod. zápis Anny (kniha 2736 fol. 187 č. 36) + sňatek 26.4.1921 (2755 sn85)
  - nar. 29.6.1900 (korektura) vs. 27.6.1900 (sňatek) — rozpor evidován
  - otec Josef Dobrovolný nar. 4/8 **1873**, matka Genovéfa nar. 27/2 **1877**
  - matčini rodiče: František Tihlař(ík) domkář + Eva roz. Forejtková(?)
- [x] **A2 HOTOV** — sňatek rodičů NALEZEN a čten: **4.10.1899 Klobouky, kniha 2755 snímek 34**
  - ženich: Jos. František Dobrovolný, volný zedník, 26 let, syn Frančišky Dobrovolného
    (domkář Klobouky, živ) a Mariany(?) roz. Veselé(?) (†)
  - nevěsta: Genovéfa Tihlař(ík)ová, 22 let, dcera Františka Tihlařika (domkář) a Evy
    roz. Forejtkové(?)
  - shoda rodičů s rod. zápisem Anny = dvojitá nezávislá shoda; datum = shoda s poznámkou
  - stara stopa „rejstřík 2786" vyvrácena (ID 2786 = Křepice)
- [x] Výstupy A2: PREPISY.md (P3), NOVE_NALEZY.json, PRAMENY.csv, PROHLEDANO.md, DENIK.md,
      obrazy_A2/ (10), 02_A_DOBROVOLNI_A2.zip

## Právě probíhá
- [ ] Úkol A3: narození Josefa (4.8.1873) a Genovéfy (27.2.1877) → kniha 2745 (narození 1859–1882)

## Překážky (zdokumentované)
- ALTCHA gate: curl nemá přístup k obrazům; řešeno legitimně přes headless browser session
- application.js a HEAD /matrika/image přes curl: prázdné/timeout (WAF) — nepodstatné
