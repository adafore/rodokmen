# CHECKPOINT — balík A (Anna Dobrovolná a její rodiče)

**Stav:** 2. 11. 2026, 13:42 UTC (~30 min práce)

## Dokončeno
- [x] Ověření vstupního ZIP (5/5 SHA256 souhlasí s MANIFEST.json)
- [x] **Úkol A1 — HOTOV** (čtení rod. zápisu č. 36 fol. 187 knihy 2736 + sňatku 2755 sn85 pag. 172)
  - Klíč: datum narození Anny s korekturou na 29.6.1900 (rozpor 27.6. v sňatku zaznamenán)
  - Otec Josef Dobrovolný nar. 4/8 **1873** (nepřijata varianta 1843)
  - Matka Genovéfa/Jenovéfa nar. **27/2 1877**, rodné příjmení čteno **Tihlař(ík)**, její otec Frančišek Tihlař(ík), domkář v Kloboukách; její matka Eva rozená **Forejtková(?)** [!neplynule Forejtník]
  - Poznámka v rod. zápise: „oddána 26/4. 1921 s Forejtníkem Bohuslavem" (NE „opravněná")
  - Blok „Oddavky se 4. října(?) 1899" — vodítko pro A2
- [x] Výstupy A1 v download/A_DOBROVOLNI/: PREPISY.md, NOVE_NALEZY.json, PRAMENY.csv, DENIK.md, obrazy_A1/ (12 výřezů), 01_A_DOBROVOLNI_A1.zip

## Právě probíhá
- [ ] Úkol A2: sňatek Josef Dobrovolný × Jenovéfa/Genovéfa Tihlař(ík)ová, 4.10.1899
  - cíl: kniha 2755, katalog ID 12400 (oddaní 1883–1948), farnost Klobouky u Brna
  - překážka sledovaná: ALTCHA gate na seznamu snímků v katalogu — testuji přístup k obrazům

## Čeká
- [ ] Úkol A3: narození Josefa (4.8.1873) a Genovéfy (27.2.1877), kniha 2736/2745+2736 série

## Překážky
- Seznam snímků v ActaPublica vyžaduje ALTCHA (autom. ověření prohlížeče) — CURL-only přístup
  neuvidí list snímků; metadat knih z katalogu je ale dost. Obrazové jp2 soubory zkouším
  získat z jejich URL patternu; pokud jsou také chráněny, budu postupovat přes
  dostupné stavy a nahlásím to jako překážku s přesným dalším krokem.
