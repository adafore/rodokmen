# PREPISY — balík A (Anna Dobrovolná a její rodiče)

Zásady: odděleno (a) doslovné čtení / (b) normalizace. Výřezy v přirozeném rozlišení,
bez zvětšování, doostřování ani jiných transformací. „[?]" = nejisté, „[nečitelné]" = nelze číst.

---

## P1 — Rodný zápis Anny Dobrovolné

**Pramen:** MZA Brno, farnost Klobouky u Brna (římskokat. církev), kniha č. 2736 (katalog
ActaPublica ID 14893), „Knaha narozených a pokřtěných — Geburths- und Taufbuch",
Annus 1900, tomus XI, fol. 186/187 (tištěné pag. 186 a 187), snímek 96.
**URL knihy:** https://www.mza.cz/actapublica/matrika/detail/14893
**Vstupní sken:** 03_anna_sn96_cely_fol186_187.jpg (7455×5846, SHA256 971449ea…e899)
**Pozice v obraze:** pravá strana (fol. 187), poslední řádek tabulky, čís. 36; textový
blok zhruba x=3830–7455, y=4380–5846. Kmotr sloupec x≈6420–7300.

### Hlavička knihy (levostranný kompozit A1_hlavicky_kompozit.png)
- (a) „Knaha narozených a pokřtěný… — Geburths- und Taufbuch.", „Annus: 1900.", „tomus: XI",
  ručně „186" (folio), nápis „Klobou…" (Klobouky), razítko/cifry 1900.
- (b) Kniha narozených Klobouky u Brna, ročník 1900, svazek XI. Katalog potvrzuje: č. knihy
  2736, narození 1883–1925, obec Klobouky u Brna, okres Břeclav.

### Zápis č. 36 (doslovně, po sloupcích)
1. Datum sloupec:
   - (a) „2[7/8?] června" — číslice přeškrtnuta, korektur níže „29."; dále dvě řádky
     drobného textu (čas narození/křtu): „V hod(?) dopl." / „ky, fa sa čt." [nečitelné]
   - (b) Narozeno (a pokřtěno) 29. června 1900; původní zapsaná číslice byla jiná
     (27/28?), oprava na 29. Čas [nečitelné].
2. Jméno křteného: (a) „Anna"
3. Sloupce „Rod Geschlecht"/„ehelich": značky „. 1 1 ." — dle souběhu s ostatními řádky
   mu odpovídá legitimní dcera (matka vstoupila „manž." = v manželství).
4. Otec:
   - (a) „Josef Dobrovol(ný) … kř?h manž: syn / Frančiška Dobr(ovolného) / volného, domka(ře)
     / z Klobouk aj(eho) / manželky Mar(ie)(?) / pag: k? olyóh(?) / Nar: 4/8 1873."
   - (b) Josef Dobrovolný, zedník [povolání uvedeno v sňatku 1921; v tomto zápisu pravděpodobně
     rovněž], manželský syn Frančiška Dobrovolného, volného domkáře z Klobouk, a jeho manželky
     Marie(?) rozené [nečitelné, hyp. K?o?yóh/Kohoutových?], nar. 4. 8. 1873.
   - Pozn.: odkaz „pag: …" = odkaz na stránku/kníhu zápisu sňatku rodičů — čtení [nejisté].
5. Matka:
   - (a) „Genovéfa manž:, / dcera Frančiška / Tihlařika a jeho / manželky Evy(?) /
     roz: Forejtkové(?) / Frančišek Tihlař(ík) / křt. j(ad?) domkář(?) / v Klobouchách /
     nar: 27/2 1877."
   - (b) Genovéfa (v sňatku 1921 psáno Jenovéfa), manželka, dcera Frančiška Tihlaříka
     a jeho manželky Evy rozené Forejtkové(?) [čteno „roz: forejtkové/forejknové"],
     Frančišek Tihlař(ík), [vzorec „křt. j(ako)?"] domkář v Kloboukách;
     Genovéfa nar. 27. 2. 1877.
6. Kmotr: (a) „Josef / Dobrovolný / nádeník(?) kovský(?) / N[otisk] / manželka / A? kor(?)"
   (b) Kmotr Josef Dobrovolný [stejné příjmení jako otec — zjevně příbuzenský kruh,
   totožnost s otcem nepravděpodobná (otec je „zedník", kmotr „nádeník(?)")], údaji
   [částečně za otiskem/rozmazáním]. Jméno manželky kmotra [nejisté, začíná „A…"].
7. Odnosní poznámka přes jmenný sloupec:
   - (a) „oddána 26/4. 1921. roce s zedníkem v Klobou(kách) / Forejtníkem Bohuslavem. /
     Bo? lcev(?) byla: heve(?) / Tavorn(?) Hova(?) č. 237."
   - (b) Oddána 26. 4. 1921 s Bohuslavem Forejtníkem [v poznámce slovo „zedníkem" — v
     sňatku 1921 je ženich „šolar(?) v Břeclavě", zedníkem je otec nevěsty; formulace
     poznámky tedy pravděpodobně odkazuje na svatebčana/povolání v širším smyslu — viz
     rozpory]. Zbylá část: pravděpodobně údaj o bydlišti č. 237; čtení místního jména
     [nejisté, hyp. „(Dobrá?) Voda č. 237"].
8. Blok „Oddavky":
   - (a) „Oddavky se / 4 ř(íj)na(?) 1899."
   - (b) Oddavky (svatba) rodičů se konaly 4. října(?) 1899 — první číslice i měsíc čteny
     s nejistotou; přesně odpovídá staré pracovní stopě „4.10.1899". Definitivní datum
     musí potvrdit sňatková matrika (úkol A2).

### Kontrola dřívějších tvrzení (předchozí běh GLM)
- „datum 27/26 a nemožný křest před narozením" — NEPOTVRZENO: čtení je „2? června"
  s korekturou na „29."; křest uveden bez vnitřního sporu.
- „poznámka zní opravněná" — NEPOTVRZENO: čtu „oddána" (oddání/sňatek), legitimace
  se v poznámce neobjevuje.
- „otec nar. 1843" — NEPOTVRZENO: čtu jednoznačně „Nar: 4/8 1873."

---

## P2 — Sňatek Bohuslav Forejtník × Anna Dobrovolná, 26. 4. 1921

**Pramen:** MZA Brno, farnost Klobouky u Brna, kniha č. 2755 (katalog ActaPublica ID 12400),
„Knaha oddaných — Trauungsbuch", Annus 1921, tomus 9, pag. 171/172, snímek 85, zápis na pravé
straně (pag. 172).
**URL knihy:** https://www.mza.cz/actapublica/matrika/detail/12400
**Vstupní sken:** C_2755_sn85_native.jpg (7353×5434, SHA256 c28fc96c…bc59)

### Hlavička
- (a) „Knaha oddaných. — Trauungsbuch." „Annus: 1921." „tomus: 9." „pag. 171/172".
  Na pravé straně horní formulař: „Pecunia in … Generali die 25 Aprilis 1921
  + Norbertus Klein episcopus" (poplatek, biskup Norbert Klein).

### Zápis (doslovně)
- Datum/místo: „1921. duben 26. Klobouky"; oddávající: „Jan Vavřinec Novotný, … z Nové Říše" [titul nejistý].
- Ženich: „Forejtník Bohuslav, šolar(?) v Břeclavě, domobranec, manž(elský) syn Karla
  Forejtníka, domkáře v Kloboukách(?), a Rosalie rozené Veselý(?) z Jaroš(?)…
  otec žije, matka …(?) nar. 3/4. 1895." — margin: „Břeclava čis. 56."
  Pozn.: rodiče ženicha jsou přiděleni jiné větvi; uvádím jen pro identifikaci sňatku.
- Nevěsta: „Dobrovolná Anna, u rodičů v Kloboukách, manželská(?) dcera Josefa
  Dobrovolského(→Dobrovolného)(?), zedníka v Kloboukách, a Jenovéfy rozené Tihlařů(→Tihlař/ík?),
  František(?) — rodiče ř. k. nábož. a žijí. nar. 27/6. 1900." — margin: „u rodičů Klobouky čis. 266."
  Věk sloupec: „20".
- Formulaře: „Dle „ne(veřejně) přiznačené knížce rodné svazku 11. st. 18ř." [odkaz na
  osvědčení, čtení nejisté]; dále zmínka osvědčení „… od bisk. Ordinariátu v Brně … č. 512".
- Souhlas rodiče s podpisem: „Josef Dobrovolný — Otec" (podpis čitelný „Josef Dobrowlný").
- Svědci: „Forejtník Rudolf, svědek"; dále „Josef Dobrovolný, dům čis. 206(?), Klobouky,
  svědek" [druhý svědek, čtení domovního čísla nejisté].

### Klíčové shody s P1 (rod. zápis č. 36)
1. Jméno nevěsty „Dobrovolná Anna" = „Anna" v zápisu č. 36 s příjmením po otci Dobrovolný.
2. Otec „Josefa Dobrovolného, zedníka v Kloboukách" = „Josef Dobrovolný" z P1 (+ vlastnoruční
   podpis otce).
3. Matka „Jenovéfy rozené Tihlařů(…)" = „Genovéfa … Tihlařika" z P1 (jen varianta křestního
   jména Jenovéfa/Genovéfa a koncovky příjmení).
4. Datum sňatku 26. 4. 1921 = datum v odnosní poznámce P1.
5. Svatba v Kloboukách (date column „Klobouky") = „v Kloboukách" v poznámce P1.

### Rozpory / pozoruhodnosti
1. **Datum narození Anny:** P1 (po korektuře) 29. 6. 1900 vs. P2 „nar. 27/6. 1900".
   Původní (přeškrtnuté) číslo v P1 je nečitelné (27/28?). Rozpor nezavřen — jiný pramen
   (rejstřík narození / matriční výpis) musí rozhodnout.
2. **Bydliště nevěsty:** P2 margin „u rodičů Klobouky čis. 266" (stav před sňatkem),
   poznámka v P1 zmiňuje „… č. 237" (místní jméno nejisté, hyp. Dobrá Voda) — pravděpodobně
   plánované/posléze společné bydliště; nelze potvrdit z přiložených obrazů.
3. **Povolání:** v P2 je zedníkem otec nevěsty („Josefa Dobrovolného, zedníka v Kloboukách"),
   ženich je „šolar(?) v Břeclavě"; odnosní poznámka P1 říká „s zedníkem" — formulace v
   poznámce tedy vychází zejména z kontextu rodiny (otec zedník), nikoli z přesného
   povolání ženicha; alternativně zednictví mohl ženich vykonávat dříve/později.
4. **„u rodičů v Kloboukách" vs. „narozená v Kloboukách":** P2 skutečně uvádí bydliště u
   rodičů („u rodičů v Kloboukách"), narození přímo netvrdí — shoda se zadáním; narození
   v Kloboukách je doloženo až P1 (kniha 2736, fol. 187 č. 36).
